﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace tetrisgame
{

    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static Dictionary<string, int> Players = new Dictionary<string, int>();
        public int PlayersCount;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // получает данные с текст бокса
            List<string> p = PlayerInfo.Text.Split().ToList(); 

            // добавление/изменение очков игрока
            if (Players.ContainsKey(p[1]))
            {
                Players[p[1]] = int.Parse(p[0]) > Players[p[1]] ? int.Parse(p[0]) : Players[p[1]];
            }
            else Players[p[1]] = int.Parse(p[0]);

            // добавление в список игроков
            string Player = String.Join(" ", p);
            PlayersInfo.Items.Add(Player);
            // для очистки текст бокса
            PlayerInfo.Text = "Введите данные участника";
        }

        private void PlayerInfo_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        private void PlayerInfo_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            // при нажатии удаляет текст введите
            TextBox txtBox = (TextBox)sender;
            if (txtBox.Text == "Введите данные участника")
            {
                txtBox.Text = "";
            }
        }
        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ShowResults_Click(object sender, RoutedEventArgs e)
        {
            // сортировка словаря игроков по их значениям
            var SortedPlayers = Players.OrderBy(x => x.Value).ToDictionary(x => x.Key, x => x.Value);
            // список для топ 3 игроков
            List<List<string>> Winners = new List<List<string>>();
            // заполнение списка
            foreach (var item in SortedPlayers) Winners.Add((item.Key.ToString() + " " + item.Value).Split().ToList());
            // С новой строки чтобы выводились игроки
            Results.Text += "\n";
            // вывод самих игроков
            for (int i = Winners.Count-1; i > Winners.Count-4; i--)
            {
                Results.Text += $"{Winners.Count-i}. {Winners[i][1]} {Winners[i][0]} \n";
            }
        }

        private void PLayersCount_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        private void PLayersCount_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            // при нажатии удаляет текст введите
            TextBox txtBox = (TextBox)sender;
            if (txtBox.Text == "Введите кол-во участников")
            {
                txtBox.Text = "";
            }
        }

        private void PlayersCountButton_Click(object sender, RoutedEventArgs e)
        {
            TextBox txtBox = (TextBox)sender;
            PlayersCount = int.Parse(txtBox.Text);
        }
    }
}